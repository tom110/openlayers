CREATE FUNCTION raster_eq(raster, raster)
  RETURNS boolean
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public.raster_hash($1) = public.raster_hash($2)
$$;

