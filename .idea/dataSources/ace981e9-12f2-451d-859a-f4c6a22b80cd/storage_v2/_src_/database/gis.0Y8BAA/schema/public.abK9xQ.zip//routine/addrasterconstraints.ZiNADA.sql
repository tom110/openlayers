CREATE FUNCTION addrasterconstraints(rasttable name, rastcolumn name, VARIADIC constraints text[])
  RETURNS boolean
STRICT
LANGUAGE SQL
AS $$
SELECT public.AddRasterConstraints('', $1, $2, VARIADIC $3)
$$;

