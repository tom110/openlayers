CREATE FUNCTION st_dfullywithin(rast1 raster, rast2 raster, distance double precision)
  RETURNS boolean
IMMUTABLE
PARALLEL SAFE
COST 1000
LANGUAGE SQL
AS $$
SELECT public.ST_DFullyWithin($1, NULL::integer, $2, NULL::integer, $3)
$$;

