CREATE FUNCTION st_intersection(rast1 raster, rast2 raster, returnband text, nodataval double precision)
  RETURNS raster
IMMUTABLE
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT st_intersection($1, 1, $2, 1, $3, ARRAY[$4, $4])
$$;

