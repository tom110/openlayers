CREATE FUNCTION st_buffer(text, double precision, integer)
  RETURNS geometry
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public.ST_Buffer($1::public.geometry, $2, $3);
$$;

