CREATE FUNCTION postgis_scripts_build_date()
  RETURNS text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT '2018-10-14 07:04:35'::text AS version
$$;

