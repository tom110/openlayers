CREATE FUNCTION st_multipointfromtext(text)
  RETURNS geometry
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public.ST_MPointFromText($1)
$$;

