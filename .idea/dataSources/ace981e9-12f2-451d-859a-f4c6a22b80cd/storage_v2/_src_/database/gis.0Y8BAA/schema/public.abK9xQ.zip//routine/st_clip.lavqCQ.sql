CREATE FUNCTION st_clip(rast raster, nband integer, geom geometry, nodataval double precision, crop boolean DEFAULT true)
  RETURNS raster
IMMUTABLE
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public.ST_Clip($1, ARRAY[$2]::integer[], $3, ARRAY[$4]::double precision[], $5)
$$;

