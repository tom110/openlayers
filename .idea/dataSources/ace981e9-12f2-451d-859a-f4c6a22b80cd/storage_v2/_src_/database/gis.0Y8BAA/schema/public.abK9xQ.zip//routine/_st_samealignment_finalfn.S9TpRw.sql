CREATE FUNCTION "_st_samealignment_finalfn"(agg agg_samealignment)
  RETURNS boolean
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT $1.aligned
$$;

