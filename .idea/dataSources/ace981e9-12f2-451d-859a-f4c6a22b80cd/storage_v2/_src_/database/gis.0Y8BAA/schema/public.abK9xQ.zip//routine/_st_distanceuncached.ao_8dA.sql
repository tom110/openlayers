CREATE FUNCTION "_st_distanceuncached"(geography, geography)
  RETURNS double precision
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT public._ST_DistanceUnCached($1, $2, 0.0, true)
$$;

