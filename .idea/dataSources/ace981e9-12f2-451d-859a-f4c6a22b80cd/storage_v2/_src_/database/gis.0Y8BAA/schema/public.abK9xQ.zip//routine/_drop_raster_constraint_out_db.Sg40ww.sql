CREATE FUNCTION "_drop_raster_constraint_out_db"(rastschema name, rasttable name, rastcolumn name)
  RETURNS boolean
STRICT
LANGUAGE SQL
AS $$
SELECT  public._drop_raster_constraint($1, $2, 'enforce_out_db_' || $3)
$$;

