CREATE FUNCTION postgis_scripts_installed()
  RETURNS text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT '2.5.0'::text || ' r' || 16836::text AS version
$$;

