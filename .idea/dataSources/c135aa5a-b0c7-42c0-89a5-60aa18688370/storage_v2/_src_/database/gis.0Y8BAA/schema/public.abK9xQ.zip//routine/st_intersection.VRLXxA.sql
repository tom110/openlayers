CREATE FUNCTION st_intersection(rast1 raster, band1 integer, rast2 raster, band2 integer, nodataval double precision)
  RETURNS raster
IMMUTABLE
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT st_intersection($1, $2, $3, $4, 'BOTH', ARRAY[$5, $5])
$$;

