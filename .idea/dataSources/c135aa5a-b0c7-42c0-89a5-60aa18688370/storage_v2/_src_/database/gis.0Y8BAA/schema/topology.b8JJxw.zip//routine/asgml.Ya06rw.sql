CREATE FUNCTION asgml(tg topology.topogeometry, nsprefix text)
  RETURNS text
STABLE
LANGUAGE SQL
AS $$
SELECT topology.AsGML($1, $2, 15, 1, NULL);
$$;

