CREATE FUNCTION postgis_raster_scripts_installed()
  RETURNS text
IMMUTABLE
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT '2.5.0'::text || ' r' || 16836::text AS version
$$;

