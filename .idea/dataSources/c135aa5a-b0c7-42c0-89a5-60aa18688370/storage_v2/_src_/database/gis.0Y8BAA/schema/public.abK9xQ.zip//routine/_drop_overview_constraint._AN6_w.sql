CREATE FUNCTION "_drop_overview_constraint"(ovschema name, ovtable name, ovcolumn name)
  RETURNS boolean
STRICT
LANGUAGE SQL
AS $$
SELECT  public._drop_raster_constraint($1, $2, 'enforce_overview_' || $3)
$$;

