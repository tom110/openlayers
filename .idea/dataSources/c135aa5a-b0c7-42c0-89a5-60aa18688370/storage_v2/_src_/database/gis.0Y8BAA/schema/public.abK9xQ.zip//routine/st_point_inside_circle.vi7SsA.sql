CREATE FUNCTION st_point_inside_circle(geometry, double precision, double precision, double precision)
  RETURNS boolean
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public._postgis_deprecate('ST_Point_Inside_Circle', 'ST_PointInsideCircle', '2.2.0');
    SELECT public.ST_PointInsideCircle($1,$2,$3,$4);
$$;

