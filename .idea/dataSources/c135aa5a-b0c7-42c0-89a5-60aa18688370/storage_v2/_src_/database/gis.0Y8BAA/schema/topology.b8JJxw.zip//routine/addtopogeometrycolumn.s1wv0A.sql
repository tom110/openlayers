CREATE FUNCTION addtopogeometrycolumn(character varying, character varying, character varying, character varying, character varying)
  RETURNS integer
LANGUAGE SQL
AS $$
SELECT topology.AddTopoGeometryColumn($1, $2, $3, $4, $5, NULL);
$$;

