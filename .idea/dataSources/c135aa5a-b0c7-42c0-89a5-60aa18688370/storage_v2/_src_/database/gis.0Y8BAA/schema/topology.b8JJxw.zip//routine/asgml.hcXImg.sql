CREATE FUNCTION asgml(tg topology.topogeometry, nsprefix text, prec integer, opts integer)
  RETURNS text
STABLE
LANGUAGE SQL
AS $$
SELECT topology.AsGML($1, $2, $3, $4, NULL);
$$;

