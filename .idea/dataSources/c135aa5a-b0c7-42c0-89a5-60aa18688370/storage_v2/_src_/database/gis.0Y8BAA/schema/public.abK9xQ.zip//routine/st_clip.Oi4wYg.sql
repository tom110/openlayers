CREATE FUNCTION st_clip(rast raster, geom geometry, crop boolean)
  RETURNS raster
IMMUTABLE
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public.ST_Clip($1, NULL, $2, null::double precision[], $3)
$$;

