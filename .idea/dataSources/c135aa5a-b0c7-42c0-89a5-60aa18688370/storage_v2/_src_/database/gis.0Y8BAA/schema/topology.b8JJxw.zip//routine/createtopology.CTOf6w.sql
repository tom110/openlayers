CREATE FUNCTION createtopology(character varying, integer)
  RETURNS integer
STRICT
LANGUAGE SQL
AS $$
SELECT topology.CreateTopology($1, $2, 0);
$$;

