CREATE FUNCTION overlaps_nd(geometry, gidx)
  RETURNS boolean
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT $2 OPERATOR(public.&&&) $1;
$$;

