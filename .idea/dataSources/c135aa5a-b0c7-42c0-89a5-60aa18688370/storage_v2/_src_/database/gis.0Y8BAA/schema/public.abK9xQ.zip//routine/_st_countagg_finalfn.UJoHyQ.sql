CREATE FUNCTION "_st_countagg_finalfn"(agg agg_count)
  RETURNS bigint
IMMUTABLE
PARALLEL SAFE
LANGUAGE plpgsql
AS $$
BEGIN
		IF agg IS NULL THEN
			RAISE EXCEPTION 'Cannot count coverage';
		END IF;

		RETURN agg.count;
	END;

$$;

