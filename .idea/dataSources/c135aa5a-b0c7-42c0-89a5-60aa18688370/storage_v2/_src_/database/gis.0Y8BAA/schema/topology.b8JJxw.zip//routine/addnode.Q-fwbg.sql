CREATE FUNCTION addnode(atopology character varying, apoint geometry)
  RETURNS integer
LANGUAGE SQL
AS $$
SELECT topology.AddNode($1, $2, false, false);
$$;

