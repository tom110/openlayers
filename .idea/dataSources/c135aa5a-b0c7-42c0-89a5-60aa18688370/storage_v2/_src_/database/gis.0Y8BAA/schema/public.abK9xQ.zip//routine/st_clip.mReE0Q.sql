CREATE FUNCTION st_clip(rast raster, nband integer[], geom geometry, nodataval double precision[] DEFAULT NULL::double precision[], crop boolean DEFAULT true)
  RETURNS raster
IMMUTABLE
PARALLEL SAFE
LANGUAGE plpgsql
AS $$
BEGIN
		-- short-cut if geometry's extent fully contains raster's extent
		IF (nodataval IS NULL OR array_length(nodataval, 1) < 1) AND geom ~ public.ST_Envelope(rast) THEN
			RETURN rast;
		END IF;

		RETURN public._ST_Clip($1, $2, $3, $4, $5);
	END;

$$;

