CREATE FUNCTION st_orderingequals(geometrya geometry, geometryb geometry)
  RETURNS boolean
IMMUTABLE
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT $1 OPERATOR(public.~=) $2 AND public._ST_OrderingEquals($1, $2)

$$;

