CREATE FUNCTION interval_pl_timetz(interval, time with time zone)
  RETURNS time with time zone
IMMUTABLE
STRICT
PARALLEL SAFE
COST 1
LANGUAGE SQL
AS $$
select $2 + $1
$$;

