CREATE FUNCTION st_approxcount(rast raster, sample_percent double precision)
  RETURNS bigint
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public._ST_count($1, 1, TRUE, $2)
$$;

