CREATE FUNCTION "_drop_raster_constraint_alignment"(rastschema name, rasttable name, rastcolumn name)
  RETURNS boolean
STRICT
LANGUAGE SQL
AS $$
SELECT  public._drop_raster_constraint($1, $2, 'enforce_same_alignment_' || $3)
$$;

