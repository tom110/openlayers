CREATE FUNCTION st_geomfromgeojson(jsonb)
  RETURNS geometry
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public.ST_GeomFromGeoJson($1::text)
$$;

