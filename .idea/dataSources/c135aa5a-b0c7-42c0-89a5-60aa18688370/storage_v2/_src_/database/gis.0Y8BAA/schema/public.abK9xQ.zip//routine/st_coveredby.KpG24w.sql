CREATE FUNCTION st_coveredby(geography, geography)
  RETURNS boolean
IMMUTABLE
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT $1 OPERATOR(public.&&) $2 AND public._ST_Covers($2, $1)
$$;

