CREATE FUNCTION st_approxsummarystats(rastertable text, rastercolumn text, exclude_nodata_value boolean)
  RETURNS summarystats
STABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public._ST_summarystats($1, $2, 1, $3, 0.1)
$$;

