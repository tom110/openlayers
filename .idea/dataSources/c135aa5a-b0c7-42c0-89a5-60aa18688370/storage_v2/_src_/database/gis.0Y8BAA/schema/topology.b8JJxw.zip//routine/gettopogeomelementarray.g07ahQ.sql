CREATE FUNCTION gettopogeomelementarray(tg topology.topogeometry)
  RETURNS topology.topoelementarray
STABLE
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
  toponame varchar;
BEGIN
  toponame = topology.GetTopologyName(tg.topology_id);
  RETURN topology.GetTopoGeomElementArray(toponame, tg.layer_id, tg.id);
END;
$$;

