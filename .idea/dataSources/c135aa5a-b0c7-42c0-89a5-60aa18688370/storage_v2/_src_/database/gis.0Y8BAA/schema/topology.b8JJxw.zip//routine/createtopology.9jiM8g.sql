CREATE FUNCTION createtopology(toponame character varying, srid integer, prec double precision)
  RETURNS integer
STRICT
LANGUAGE SQL
AS $$
SELECT topology.CreateTopology($1, $2, $3, false);
$$;

