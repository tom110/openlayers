CREATE FUNCTION asgml(tg topology.topogeometry, nsprefix text, prec integer, options integer, vis regclass)
  RETURNS text
LANGUAGE SQL
AS $$
SELECT topology.AsGML($1, $2, $3, $4, $5, '');
$$;

