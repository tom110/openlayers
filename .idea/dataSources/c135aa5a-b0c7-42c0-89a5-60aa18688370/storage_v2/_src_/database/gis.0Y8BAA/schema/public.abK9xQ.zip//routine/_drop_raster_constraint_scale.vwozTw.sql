CREATE FUNCTION "_drop_raster_constraint_scale"(rastschema name, rasttable name, rastcolumn name, axis character)
  RETURNS boolean
STRICT
LANGUAGE plpgsql
AS $$
BEGIN
		IF lower($4) != 'x' AND lower($4) != 'y' THEN
			RAISE EXCEPTION 'axis must be either "x" or "y"';
			RETURN FALSE;
		END IF;

		RETURN  public._drop_raster_constraint($1, $2, 'enforce_scale' || $4 || '_' || $3);
	END;

$$;

