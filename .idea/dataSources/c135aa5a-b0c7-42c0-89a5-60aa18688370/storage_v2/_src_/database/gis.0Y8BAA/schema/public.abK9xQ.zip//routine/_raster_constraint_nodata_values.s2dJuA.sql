CREATE FUNCTION "_raster_constraint_nodata_values"(rast raster)
  RETURNS numeric[]
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT array_agg(round(nodatavalue::numeric, 10))::numeric[] FROM public.ST_BandMetaData($1, ARRAY[]::int[]);
$$;

