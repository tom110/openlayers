CREATE FUNCTION createtopology(character varying)
  RETURNS integer
STRICT
LANGUAGE SQL
AS $$
SELECT topology.CreateTopology($1, ST_SRID('POINT EMPTY'::geometry), 0);
$$;

