CREATE FUNCTION topoelementarray_append(topology.topoelementarray, topology.topoelement)
  RETURNS topology.topoelementarray
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT CASE
		WHEN $1 IS NULL THEN
			topology.TopoElementArray('{' || $2::text || '}')
		ELSE
			topology.TopoElementArray($1::int[][]||$2::int[])
		END;
$$;

