CREATE FUNCTION st_bandisnodata(rast raster, forcechecking boolean)
  RETURNS boolean
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public.ST_bandisnodata($1, 1, $2)
$$;

