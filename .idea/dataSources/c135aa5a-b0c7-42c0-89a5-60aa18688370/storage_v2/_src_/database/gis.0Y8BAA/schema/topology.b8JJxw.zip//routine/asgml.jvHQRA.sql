CREATE FUNCTION asgml(tg topology.topogeometry, nsprefix text, prec integer, options integer, visitedtable regclass, idprefix text)
  RETURNS text
LANGUAGE SQL
AS $$
SELECT topology.AsGML($1, $2, $3, $4, $5, $6, 3);
$$;

