CREATE FUNCTION lockrow(text, text, text, timestamp without time zone)
  RETURNS integer
STRICT
LANGUAGE SQL
AS $$
SELECT LockRow(current_schema(), $1, $2, $3, $4);
$$;

