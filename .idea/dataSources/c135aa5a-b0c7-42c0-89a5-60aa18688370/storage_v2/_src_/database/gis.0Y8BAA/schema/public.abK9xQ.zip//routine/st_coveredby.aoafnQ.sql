CREATE FUNCTION st_coveredby(rast1 raster, rast2 raster)
  RETURNS boolean
IMMUTABLE
PARALLEL SAFE
COST 1000
LANGUAGE SQL
AS $$
SELECT public.st_coveredby($1, NULL::integer, $2, NULL::integer)
$$;

