CREATE FUNCTION droprasterconstraints(rasttable name, rastcolumn name, VARIADIC constraints text[])
  RETURNS boolean
STRICT
LANGUAGE SQL
AS $$
SELECT  public.DropRasterConstraints('', $1, $2, VARIADIC $3)
$$;

