CREATE FUNCTION gettopologysrid(toponame character varying)
  RETURNS integer
STABLE
STRICT
LANGUAGE SQL
AS $$
SELECT SRID FROM topology.topology WHERE name = $1;
$$;

