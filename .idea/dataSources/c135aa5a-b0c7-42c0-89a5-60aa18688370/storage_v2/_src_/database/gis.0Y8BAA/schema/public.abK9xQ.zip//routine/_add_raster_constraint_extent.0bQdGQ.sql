CREATE FUNCTION "_add_raster_constraint_extent"(rastschema name, rasttable name, rastcolumn name)
  RETURNS boolean
STRICT
COST 9000
LANGUAGE plpgsql
AS $$
DECLARE
		fqtn text;
		cn name;
		sql text;
		attr text; srid integer;
	BEGIN
		fqtn := '';
		IF length($1) > 0 THEN
			fqtn := quote_ident($1) || '.';
		END IF;
		fqtn := fqtn || quote_ident($2);

		sql := 'SELECT public.ST_SRID('
            || quote_ident($3)
      || ') FROM '
            || fqtn
            || ' LIMIT 1;';
    EXECUTE sql INTO srid;

		cn := 'enforce_max_extent_' || $3;

		sql := 'SELECT public.st_ashexewkb( public.st_setsrid( public.st_extent( public.st_envelope('
			|| quote_ident($3)
			|| ')), ' || srid || ')) FROM '
			|| fqtn;
		EXECUTE sql INTO attr;

		-- NOTE: I put NOT VALID to prevent the costly step of validating the constraint
		sql := 'ALTER TABLE ' || fqtn
			|| ' ADD CONSTRAINT ' || quote_ident(cn)
			|| ' CHECK ( public.st_envelope('
			|| quote_ident($3)
			|| ') @ ''' || attr || '''::geometry) NOT VALID';
		RETURN  public._add_raster_constraint(cn, sql);
	END;

$$;

