CREATE FUNCTION st_dwithin(rast1 raster, rast2 raster, distance double precision)
  RETURNS boolean
IMMUTABLE
PARALLEL SAFE
COST 1000
LANGUAGE SQL
AS $$
SELECT public.st_dwithin($1, NULL::integer, $2, NULL::integer, $3)
$$;

