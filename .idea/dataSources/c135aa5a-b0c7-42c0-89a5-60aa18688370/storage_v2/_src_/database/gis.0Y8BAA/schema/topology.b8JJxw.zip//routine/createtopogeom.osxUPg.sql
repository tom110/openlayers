CREATE FUNCTION createtopogeom(toponame character varying, tg_type integer, layer_id integer)
  RETURNS topology.topogeometry
STRICT
LANGUAGE SQL
AS $$
SELECT topology.CreateTopoGeom($1,$2,$3,'{{0,0}}');
$$;

