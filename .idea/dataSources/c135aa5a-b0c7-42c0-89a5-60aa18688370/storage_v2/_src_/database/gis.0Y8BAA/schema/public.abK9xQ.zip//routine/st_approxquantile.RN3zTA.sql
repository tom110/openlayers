CREATE FUNCTION st_approxquantile(rastertable text, rastercolumn text, nband integer, sample_percent double precision, quantile double precision)
  RETURNS double precision
STABLE
STRICT
LANGUAGE SQL
AS $$
SELECT ( public._ST_quantile($1, $2, $3, TRUE, $4, ARRAY[$5]::double precision[])).value
$$;

