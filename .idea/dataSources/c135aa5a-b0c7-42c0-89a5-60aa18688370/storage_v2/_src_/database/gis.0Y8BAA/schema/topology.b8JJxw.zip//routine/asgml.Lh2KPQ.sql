CREATE FUNCTION asgml(tg topology.topogeometry)
  RETURNS text
STABLE
LANGUAGE SQL
AS $$
SELECT topology.AsGML($1, 'gml');
$$;

