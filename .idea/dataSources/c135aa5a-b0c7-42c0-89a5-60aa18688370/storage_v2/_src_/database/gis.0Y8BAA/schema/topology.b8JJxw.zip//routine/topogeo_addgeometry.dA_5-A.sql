CREATE FUNCTION topogeo_addgeometry(atopology character varying, ageom geometry, tolerance double precision DEFAULT 0)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
BEGIN
	RAISE EXCEPTION 'TopoGeo_AddGeometry not implemented yet';
END
$$;

