CREATE FUNCTION "_add_overview_constraint"(ovschema name, ovtable name, ovcolumn name, refschema name, reftable name, refcolumn name, factor integer)
  RETURNS boolean
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
		fqtn text;
		cn name;
		sql text;
	BEGIN
		fqtn := '';
		IF length($1) > 0 THEN
			fqtn := quote_ident($1) || '.';
		END IF;
		fqtn := fqtn || quote_ident($2);

		cn := 'enforce_overview_' || $3;

		sql := 'ALTER TABLE ' || fqtn
			|| ' ADD CONSTRAINT ' || quote_ident(cn)
			|| ' CHECK ( public._overview_constraint(' || quote_ident($3)
			|| ',' || $7
			|| ',' || quote_literal($4)
			|| ',' || quote_literal($5)
			|| ',' || quote_literal($6)
			|| '))';

		RETURN  public._add_raster_constraint(cn, sql);
	END;

$$;

