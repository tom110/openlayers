CREATE FUNCTION st_covers(text, text)
  RETURNS boolean
IMMUTABLE
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public.ST_Covers($1::public.geometry, $2::public.geometry);
$$;

