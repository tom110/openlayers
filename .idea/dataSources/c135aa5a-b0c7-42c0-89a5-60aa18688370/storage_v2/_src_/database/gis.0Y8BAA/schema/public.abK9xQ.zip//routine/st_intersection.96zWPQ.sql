CREATE FUNCTION st_intersection(rast raster, geomin geometry)
  RETURNS SETOF geomval
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public.ST_Intersection($2, $1, 1)
$$;

