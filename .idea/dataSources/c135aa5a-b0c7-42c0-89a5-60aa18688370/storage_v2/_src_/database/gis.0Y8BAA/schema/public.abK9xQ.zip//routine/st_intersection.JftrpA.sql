CREATE FUNCTION st_intersection(rast raster, band integer, geomin geometry)
  RETURNS SETOF geomval
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public.ST_Intersection($3, $1, $2)
$$;

