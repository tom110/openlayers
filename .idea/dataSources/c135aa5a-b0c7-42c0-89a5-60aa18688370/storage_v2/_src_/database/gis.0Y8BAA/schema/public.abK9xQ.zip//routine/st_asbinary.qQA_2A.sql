CREATE FUNCTION st_asbinary(raster, outasin boolean DEFAULT false)
  RETURNS bytea
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public.ST_AsWKB($1, $2)
$$;

