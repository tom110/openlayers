CREATE FUNCTION asgml(tg topology.topogeometry, visitedtable regclass)
  RETURNS text
LANGUAGE SQL
AS $$
SELECT topology.AsGML($1, 'gml', 15, 1, $2);
$$;

