CREATE FUNCTION gettopologyname(topoid integer)
  RETURNS character varying
STABLE
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
  ret varchar;
BEGIN
        SELECT name FROM topology.topology into ret
                WHERE id = topoid;
  RETURN ret;
END
$$;

