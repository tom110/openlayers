CREATE FUNCTION st_intersects(rast raster, nband integer, geom geometry)
  RETURNS boolean
IMMUTABLE
PARALLEL SAFE
COST 1000
LANGUAGE SQL
AS $$
SELECT $1::geometry OPERATOR(public.&&) $3 AND public._st_intersects($3, $1, $2)
$$;

