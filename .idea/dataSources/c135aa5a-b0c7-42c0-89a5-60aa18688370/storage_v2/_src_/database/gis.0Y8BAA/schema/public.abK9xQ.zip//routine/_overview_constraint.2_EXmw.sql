CREATE FUNCTION "_overview_constraint"(ov raster, factor integer, refschema name, reftable name, refcolumn name)
  RETURNS boolean
STABLE
LANGUAGE SQL
AS $$
SELECT COALESCE((SELECT TRUE FROM public.raster_columns WHERE r_table_catalog = current_database() AND r_table_schema = $3 AND r_table_name = $4 AND r_raster_column = $5), FALSE)
$$;

