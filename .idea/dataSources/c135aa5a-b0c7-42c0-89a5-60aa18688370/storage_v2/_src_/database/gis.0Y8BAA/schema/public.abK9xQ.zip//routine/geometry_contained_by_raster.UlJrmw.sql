CREATE FUNCTION geometry_contained_by_raster(geometry, raster)
  RETURNS boolean
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
select $1 OPERATOR(public.@) $2::geometry
$$;

