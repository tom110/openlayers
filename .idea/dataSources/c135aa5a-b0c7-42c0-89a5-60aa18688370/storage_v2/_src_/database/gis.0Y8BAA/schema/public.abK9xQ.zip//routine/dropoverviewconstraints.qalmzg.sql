CREATE FUNCTION dropoverviewconstraints(ovtable name, ovcolumn name)
  RETURNS boolean
STRICT
LANGUAGE SQL
AS $$
SELECT  public.DropOverviewConstraints('', $1, $2)
$$;

