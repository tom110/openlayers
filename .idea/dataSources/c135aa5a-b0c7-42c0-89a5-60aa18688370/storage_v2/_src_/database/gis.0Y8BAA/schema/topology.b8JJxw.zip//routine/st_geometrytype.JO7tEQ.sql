CREATE FUNCTION st_geometrytype(tg topology.topogeometry)
  RETURNS text
STABLE
STRICT
LANGUAGE SQL
AS $$
SELECT CASE
		WHEN type($1) = 1 THEN 'ST_MultiPoint'
		WHEN type($1) = 2 THEN 'ST_MultiLinestring'
		WHEN type($1) = 3 THEN 'ST_MultiPolygon'
		WHEN type($1) = 4 THEN 'ST_GeometryCollection'
		ELSE 'ST_Unexpected'
		END;
$$;

