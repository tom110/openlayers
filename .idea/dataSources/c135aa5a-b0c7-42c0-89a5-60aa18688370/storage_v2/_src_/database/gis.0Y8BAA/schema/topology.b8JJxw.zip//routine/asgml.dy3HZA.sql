CREATE FUNCTION asgml(tg topology.topogeometry, visitedtable regclass, nsprefix text)
  RETURNS text
LANGUAGE SQL
AS $$
SELECT topology.AsGML($1, $3, 15, 1, $2);
$$;

