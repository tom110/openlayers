CREATE FUNCTION "_raster_constraint_pixel_types"(rast raster)
  RETURNS text[]
STABLE
STRICT
LANGUAGE SQL
AS $$
SELECT array_agg(pixeltype)::text[] FROM  public.ST_BandMetaData($1, ARRAY[]::int[]);
$$;

